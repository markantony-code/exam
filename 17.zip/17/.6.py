# -*- coding: utf-8 -*-
"""
Created on Sat Oct 19 12:35:43 2019

@author: Atharva
"""
import pandas as pd
import numpy as np

df = pd.read_csv('06_DT_BikeShareData.csv')
df.head()

df.info()

X = df.iloc[:,[0,3,5]]
y = df.iloc[:,-1]

X.isnull().any()
y.isnull().any()
print(y)

X=X.values
y=y.values

from sklearn.preprocessing import LabelEncoder
lenc=LabelEncoder()
y=lenc.fit_transform(y)
print("Sample y:",y[:5])
print("0 :",lenc.classes_[0])
print("1 :",lenc.classes_[1])

from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.25)

from sklearn.tree import DecisionTreeClassifier
classifier = DecisionTreeClassifier(criterion='entropy', min_samples_leaf=100)
classifier.fit(X_train,y_train)

y_pred = classifier.predict(X_test)

from sklearn.metrics import confusion_matrix,accuracy_score
print(confusion_matrix(y_test,y_pred))
print(accuracy_score(y_test,y_pred)*100)
