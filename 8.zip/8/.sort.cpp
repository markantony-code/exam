#include<iostream>
#include<omp.h>
#include<stdlib.h>
using namespace std;
void bubble(int* ,int);
void swap(int &,int &);
void mergesort(int a[],int i, int j);
void merge(int a[],int i1, int j1, int i2, int j2);

void mergesort(int a[],int i ,int j){
	int mid;
	if(i<j){
		mid=(i+j)/2;
		#pragma omp parallel sections
		{
			#pragma omp section
			{
				mergesort(a,i,mid);
			}
			#pragma omp section
			{
				mergesort(a,mid+1,j);
			}
		}
		 merge(a,i,mid,mid+1,j);
	}
}

void merge(int a[],int i1,int j1,int i2, int j2){
	int i=i1;
	int j=i2;
	int temp[10],k=0;
	while(i<=j1 && j<=j2){
		if(a[i]<a[j])
			temp[k++]=a[i++];
		else
			temp[k++]=a[j++];
	}
	while(i<=j1)
		temp[k++]=a[i++];

	while(j<=j2)
		temp[k++]=a[j++];

	for(int i=i1,j=0;i<=j2;i++,j++)
		a[i]=temp[j];
}

void bubble(int *a,int n){
	for(int i=0;i<n;i++){
		int first=i%2;
		#pragma omp parallel for shared(a,first)
		for(int j=first;j<n-1;j+=2){
			if(a[j]>a[j+1])
				swap(a[j],a[j+1]);
		}
	}
}

void swap(int &a,int &b){
	int temp=a;
	a=b;
	b=temp;
}
int main(){
	int n;
	int *a;
	
	cout<<"\nEnter number of elements: ";
	cin>>n;
	cout<<"\nEnter elements:\n";
	for(int i=0;i<n;i++){
		cin>>a[i];
		//b[i]=a[i];
	}
	cout<<"\n1. Bubble sort";
	cout<<"\n2. Merge sort"<<endl;
	int ch;
	cin>>ch;
	switch(ch){
		case 1:
		{
			bubble(a,n);
			break;
		}
		case 2:
		{
			mergesort(a,0,n-1);
		}
	}
	
	cout<<"\nArray after sort: ";
	for(int i=0;i<n;i++){
		cout<<a[i]<<" ";
	}

	return 0;

}