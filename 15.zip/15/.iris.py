# import pandas as pd
# import numpy as np
# import matplotlib.pyplot as plt

# # Importing Dataset
# data_set = pd.read_csv('Iris.csv')
# # X = data_set.iloc[:, :-1]   # Independent Variables separated as X
# # y = data_set.iloc[:, -1]    # Dependent Variables into y
# # print("IV".center(40, "_"), '\n', X.head())
# # print("DV".center(40, "_"), '\n', y.head())

# # Check for Missing Values
# # print(X.isnull().any())
# # print(y.isnull().any())

# # Summary
# print("Summary")
# print(data_set.info())
# print(data_set.head())
# print("mean: ",np.mean(data_set.iloc[:,[0]].values),np.mean(data_set.iloc[:,[1]].values),np.mean(data_set.iloc[:,[2]].values),np.mean(data_set.iloc[:,[3]].values))
# print(np.min(data_set.iloc[:,[0]]))
# plt.hist(data_set.iloc[:,-1],3,facecolor='blue',alpha=0.5)
# plt.show()
# data_set.boxplot()
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('iris.csv')
print("Description:")
df.describe()
print("Minimum value:")
df.min()
print("Maximum value:")
df.max()
print("Average value:")
df.mean()
print("Std dev value:")
df.std()
print("Variance value:")
df.var()
print("Percentiles:")
df.quantile([0, .25, .5, .75, 1]) 

print("Histograms:")
df.hist()

print("BoxPlots:")
df.boxplot()