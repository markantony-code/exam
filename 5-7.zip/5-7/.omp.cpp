#include<bits/stdc++.h>
#include<omp.h>
using namespace std;
void largevec(){
	int max=100;
	int a[max],b[max],c[max];

	cout<<"\nVector A: ";
	#pragma omp parallel for
	for(int i=0;i<max;i++)
		a[i]=rand()%100;

	for(int i=0;i<max;i++)
		cout<<a[i]<<" ";

	cout<<"\nVector B: ";
	#pragma omp parallel for
	for(int i=0;i<max;i++)
		b[i]=rand()%100;

	for(int i=0;i<max;i++)
		cout<<b[i]<<" ";

	cout<<"\n Vector C: ";
	#pragma omp parallel for
	for(int i=0;i<max;i++)
		c[i]=a[i]+b[i];

	for(int i=0;i<max;i++)
		cout<<c[i]<<" ";
}
void matmatmult(){
	int n=4;
	float a[n][n],b[n][n],c[n][n];
	#pragma omp parallel for
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			a[i][j]=rand()%5;
			b[i][j]=rand()%5;
		}
	}

	cout<<"\nA: "<<endl;
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			cout<<a[i][j]<<"  ";
		}
		cout<<"\n";
	}

	cout<<"\nB: "<<endl;
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			cout<<b[i][j]<<"  ";
		}
		cout<<"\n";
	}
	omp_set_num_threads(n*n);

	int k=0;
	int i,j;

	#pragma omp parallel for private(k,j)
	for(i=0;i<n;i++){
		for(int j=0;j<n;j++){
			c[i][j]=0;
			for(k=0;k<n;k++){
				c[i][j]+=a[i][k]*b[k][j];
			}
		}
	}

	cout<<"\nC: ";
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			cout<<c[i][j]<<"  ";
		}
		cout<<"\n";
	}

}
void matvecmult(){
	int m=3,n=2;
	int a[m][n],b[n],c[n];

	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
			a[i][j]=1;
			
		}
	}

	cout<<"\nA: "<<endl;
	for(int i=0;i<m;i++){
		for(int j=0;j<n;j++){
			cout<<a[i][j]<<"  ";
		}
		cout<<"\n";
	}

	for(int i=0;i<n;i++)
		b[i]=2;

	cout<<"\nB: "<<endl;
	for(int i=0;i<n;i++)
		cout<<b[i]<<endl;

	#pragma omp parallel for 
	for(int i=0;i<m;i++){
		c[i]=0;
		for(int j=0;j<n;j++)
			c[i]+=a[i][j]*b[j];
	}

	cout<<"\nC: "<<endl;
	for(int i=0;i<n;i++)
		cout<<c[i]<<endl;

}
int main(){
	int ch=0;
	while(ch!=4){
		cout<<"\n1.Large vec add";
		cout<<"\n2.Mat mat mult";
		cout<<"\n3.Mat vec mult";
		
		cin>>ch;
		switch(ch){
			case 1:{
				largevec();
				break;
			}
			case 2:{
				matmatmult();
				break;
			}
			case 3:{
				matvecmult();
			}
		}
	}
	return 0;
}