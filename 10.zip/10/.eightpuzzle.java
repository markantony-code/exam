package eightpuzl;

public class eightpuzzle {
		private Board start;
		private Board goal;
		private int gn=0;
	public static void main(String args[]) {
		eightpuzzle ep = new eightpuzzle();
		ep.initStart();
		ep.initGoal();
		ep.solve();
	}

	private void solve() {
		// TODO Auto-generated method stub
		Board curr=start;
		while(true) {
			System.out.println("board after "+gn+" moves: ");
			curr.display();
			if(curr.equals(goal)) {
				System.out.println("Goal state achieved!");
				return;
			}
			gn++;
			curr=curr.nextMove(gn,goal);
		}
	}

	private void initGoal() {
		// TODO Auto-generated method stub
		goal = new Board();
		goal.initBoard();
		System.out.println("Goal State: ");
		goal.display();
	}

	private void initStart() {
		// TODO Auto-generated method stub
		start = new Board();
		start.initBoard();
		System.out.println("Start State: ");
		start.display();
	}
}
