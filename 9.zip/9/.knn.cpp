#include <stdlib.h>
#include<mpi.h>
#include<stdio.h>
#include<string.h>
#include<fstream>
#include<time.h>
#include<math.h>
#include<iostream>
using namespace std;

double atof(const char* str);

float euclidean(float ex1[1][4],float ex2[1][4]){
	float distance=0;

	for(int i=0;i<4;i++)
		distance+=pow((ex1[0][i]-ex2[0][i]),2);

	distance=sqrt(distance);
	return distance;
}

string classify(float dist[][2],int K,string iris_data_raw[][5]){


	int classOneCount=0,classTwoCount=0,classThreeCount=0;

	string classOne = "Iris-setosa";
	string classTwo = "Iris-versicolor";
	string classThree = "Iris-virginica";
	

	cout<<"Counting nearest classes: "<<endl;
	for(int i=0;i<K;i++){
		if(iris_data_raw[(int)dist[i][0]][4]==classOne)
			classOneCount++;
		else if(iris_data_raw[(int)dist[i][0]][4]==classTwo)
			classTwoCount++;
		else
			classThreeCount++;
	}
	return(classOneCount>classTwoCount?
			(classOneCount>classThreeCount?classOne:classThree):
			(classTwoCount>classThreeCount?classTwo:classThree));

	

}

void process(int my_id,int K,int examples[20],string iris_data_raw[][5],float iris_data[][4]){

	int example_number=examples[my_id];
	float distances[150][2];
	for(int i=0;i<150;i++){
		distances[i][0]=i;
		if(i==example_number)
			distances[i][1]=1000;
		else
			distances[i][1]=euclidean(&iris_data[example_number],&iris_data[i]);
	}

	for(int i=0;i<150;i++){
		for(int j=0;j<150-i-1;j++){
			if(distances[j][1]>distances[j+1][1]){
				float swap_distance = distances[j][1];
				distances[j][1]=distances[j+1][1];
				distances[j+1][1]=swap_distance;

				float swap_index = distances[j][0];
				distances[j][0]=distances[j+1][0];
				distances[j+1][0]=swap_index;
			}
		}
	}

	cout<<"Thread : "<<my_id<<" | The example "<<examples[my_id]<<" belongs to the class : "<<classify(distances,K,iris_data_raw)<<endl;
	
}

int main(int argc, char** argv){

	string iris_data_raw[150][5];
	float iris_data[150][4];

	int K=13;
	int examples[20];

	ifstream iris_file;

	for(int i=0;i<20;i++)
		examples[i]=rand()%150;

	iris_file.open("iris.csv");
	while(!iris_file.eof()){
		for(int i=0;i<150;i++)
			for(int j=0;j<5;j++)
				getline(iris_file,iris_data_raw[i][j],',');
	}

	//iris_data_raw[0][0]="5.1";

	int ierr,my_id,num_procs;

	MPI_Status stat;
	ierr=MPI_Init(&argc,&argv);
	ierr=MPI_Comm_rank(MPI_COMM_WORLD,&my_id);
	ierr=MPI_Comm_size(MPI_COMM_WORLD,&num_procs);

	if(my_id==0){
		char parse_to_float[3];

		for(int i=0;i<150;i++){
			for(int j=0;j<5;j++){
				strcpy(parse_to_float,iris_data_raw[i][j].c_str());
				iris_data[i][j]=atof(parse_to_float);
			}
		}

		for(int i=1;i<num_procs;i++){
			cout<<"Sending data: "<<i<<endl;
			MPI_Send(iris_data,600,MPI_FLOAT,i,0,MPI_COMM_WORLD);
		}

		process(my_id,K,examples,iris_data_raw,iris_data);
	}
	else{
		float iris_data_recvd[150][4];

		MPI_Recv(iris_data_recvd,600,MPI_FLOAT,0,0,MPI_COMM_WORLD,&stat);
		cout<<"Received by: "<<my_id<<endl;
		process(my_id,K,examples,iris_data_raw,iris_data_recvd);
	}

	ierr=MPI_Finalize();	

}


/*
 mpic++ knn.cpp
atoo@atoo-VirtualBox:~/Desktop/KNN$ mpirun -np 20 ./a.out
Sending data: 1
Sending data: 2
Sending data: 3
Sending data: 4
Sending data: 5
Sending data: 6
Sending data: 7
Sending data: 8
Sending data: 9
Sending data: 10
Sending data: 11Received by: 
Sending data: 12
9Sending data: 13

Sending data: Thread : 14
Sending data: 15
Received by: Sending data: 16
Sending data: 2
Thread : 2 | The example 27 belongs to the class : Counting nearest classes: 
Iris-setosa
17
Sending data: 18
Sending data: 19
Thread : 0 | The example 133 belongs to the class : Counting nearest classes: 
Iris-virginica
9 | The example 121 belongs to the class : Counting nearest classes: 
Iris-virginica
Received by: Received by: 13
Thread : Received by: 13 | The example 109 belongs to the class : Counting nearest classes: 
Iris-virginica
Received by: Received by: 18
Thread : Received by: 4
18Thread :  | The example 22 belongs to the class : Counting nearest classes: 
Iris-setosa
Received by: 4 | The example 143 belongs to the class : Counting nearest classes: 
Iris-virginica
Received by: 3
Received by: 17Thread : 
Thread : 110
Thread : 
Thread : 3 | The example 115 belongs to the class : Counting nearest classes: 
Iris-virginica17
 | The example 1261 | The example  belongs to the class : Counting nearest classes: 136 belongs to the class : 
Counting nearest classes: Iris-versicolor

Iris-virginica
10 | The example 62 belongs to the class : 12Counting nearest classes: 
Iris-versicolor

Thread : 12 | The example 140 belongs to the class : Counting nearest classes: 
Iris-virginica
6
Thread : 6 | The example 136 belongs to the class : Counting nearest classes: 
Iris-virginica
Received by: Received by: 11
Thread : 11 | The example 127 belongs to the class : Counting nearest classes: 
Iris-virginica
19
Thread : 19 | The example 136 belongs to the class : Counting nearest classes: 
Iris-virginica
Received by: Received by: 15
Thread : 15 | The example 76 belongs to the class : Counting nearest classes: 
Iris-versicolor
5
Thread : 5 | The example 85 belongs to the class : Counting nearest classes: 
Iris-versicolor
Received by: Received by: 14
Thread : 16
Thread : 14 | The example 113 belongs to the class : Counting nearest classes: 
Iris-virginica
16 | The example 90 belongs to the class : Counting nearest classes: 
Iris-versicolor
Received by: 7
Thread : 7 | The example 42 belongs to the class : Counting nearest classes: 
Iris-setosa
Received by: 8
Thread : 8 | The example 99 belongs to the class : Counting nearest classes: 
Iris-versicolor

===================================================================================
=   BAD TERMINATION OF ONE OF YOUR APPLICATION PROCESSES
=   PID 2689 RUNNING AT atoo-VirtualBox
=   EXIT CODE: 139
=   CLEANING UP REMAINING PROCESSES
=   YOU CAN IGNORE THE BELOW CLEANUP MESSAGES
===================================================================================
YOUR APPLICATION TERMINATED WITH THE EXIT STRING: Segmentation fault (signal 11)
This typically refers to a problem with your application.
Please see the FAQ page for debugging suggestions


*/